import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Show the "Game Over"
 * 
 * 卢涵彬
 * 2021.5.5
 */
public class GameOver extends GUI
{
    public void act() {
        getWorld().removeObjects(getWorld().getObjects(Scroller.class));
    }    
}  
