import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * To guide the player to click the START
 * 
 * 郑斐特 
 * 2021.5.20
 */
public class mouse extends GUI
{
    /**
     * Act - do whatever the mouse wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move();
    }
     private void move(){
         int i=0;
        if(blood.flag){setLocation(getX(), getY()-1);
        if (getY() == 330) { 
            setLocation(290,350 );
        }}
        
}
}
