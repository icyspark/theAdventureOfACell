import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public abstract class Scroller extends Actor{
    private static int speed=5;
    public void act() {
        move();
    }
    
    private void move(){
        if(blood.flag){setLocation(getX() - speed, getY());
        if (getX() <= 0) {  //若抵达左边界则从游戏场景移除
            getWorld().removeObject(this);
        }}
        
}
}
