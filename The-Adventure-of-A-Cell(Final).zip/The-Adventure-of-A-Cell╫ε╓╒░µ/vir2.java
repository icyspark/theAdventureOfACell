import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This displays the image of the second kind of virus. 
 * If you click it, it will present the scientific information about a real virus
 * 郑斐特
 * 2021.5.20
 */
public class vir2 extends CollectionOfVirus
{
    /**
     * Act - do whatever the vir2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void vir2(){
    act();}
    public void act() 
    {   
        
         if ((Greenfoot.mouseClicked(this))){
             real2 real=new real2();
             second_info info=new second_info();
             
             getWorld().addObject(real,450,150);
             getWorld().addObject(info,275,160);
             getWorld().removeObjects(getWorld().getObjects(CollectionOfVirus.class));
             
        }
    }
    
}
