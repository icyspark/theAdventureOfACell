import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Click to exit the game
 * 
 * 郑斐特
 * 2021.5.19
 */
public class Exit extends GUI
{
    /**
     * Act - do whatever the Exit wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       if ((Greenfoot.mouseClicked(this))){
            blood A=new blood();
            Greenfoot.setWorld(A);
            again.run=false;
    }
    }    
}
