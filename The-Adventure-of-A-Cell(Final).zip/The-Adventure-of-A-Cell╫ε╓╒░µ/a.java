import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *This a button which can present you the author's name
 * 
 * 郑斐特
 * 2021.5.20
 */
public class a extends GUI
{
    /**
     * Act - do whatever the a wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if ((Greenfoot.mouseClicked(this))){
            Copyright author=new Copyright();
            Greenfoot.setWorld(author);
    }
}
private static a A=new a();
    private a(){};
    public static a getInstance(){
    return A;
}
}
