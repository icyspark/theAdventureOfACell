import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *This a button which can present you the information about the virus
 * 
 * 郑斐特
 * 2021.5.20
 */
public class c extends GUI
{
    /**
     * Act - do whatever the c wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if ((Greenfoot.mouseClicked(this))){
            science_intro intro=new science_intro();
            Greenfoot.setWorld(intro);
    }
    }
    private static c C=new c();
    private c(){};
    public static c getInstance(){
    return C;
}
}
