import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is simply a collection that contains various virus, which will be 
 * displayed in the "science-intro".
 * 
 * 郑斐特 
 * 2021.5.19
 */
public abstract class CollectionOfVirus extends Actor //extends strategyControl
{
    
    /**
     * Act - do whatever the CollectionOfVirus wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act(){
    };
   
}
