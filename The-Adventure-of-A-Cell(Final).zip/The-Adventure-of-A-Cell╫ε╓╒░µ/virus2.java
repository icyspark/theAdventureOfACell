
public class virus2 extends Virus
{
 
}
