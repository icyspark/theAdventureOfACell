
public class virus3 extends Virus
{
 
}
