import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This displays the image of the third kind of virus. 
 * If you click it, it will present the scientific information about a real virus
 * 郑斐特
 * 2021.5.20
 */
public class vir3 extends CollectionOfVirus
{
    /**
     * Act - do whatever the vir3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
         if ((Greenfoot.mouseClicked(this))){
             real3 real=new real3();
             third_info info=new third_info();
             getWorld().addObject(real,450,150);
             getWorld().addObject(info,230,200);
           getWorld().removeObjects(getWorld().getObjects(CollectionOfVirus.class));
        }
    }
    
}
