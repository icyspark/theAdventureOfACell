
public class virus4 extends Virus
{
 
}
