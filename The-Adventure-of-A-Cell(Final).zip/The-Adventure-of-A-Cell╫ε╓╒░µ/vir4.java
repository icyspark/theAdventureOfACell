import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This displays the image of the fourth kind of virus. 
 * If you click it, it will present the scientific information about a real virus
 * 郑斐特
 * 2021.5.20
 */
public class vir4 extends CollectionOfVirus
{
    /**
     * Act - do whatever the vir4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        if ((Greenfoot.mouseClicked(this))){
            real4 real=new real4();
            fourth_info info=new fourth_info();
            getWorld().addObject(real,450,150);
            getWorld().addObject(info,200,200);
           getWorld().removeObjects(getWorld().getObjects(CollectionOfVirus.class));
        }
    }
    
}
