import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Score extends Actor
{
    GreenfootImage newImage;
    //构造方法，初始化计分对象
public Score(){
        newImage = new GreenfootImage(80, 120);
        setScore(0);
    }
    //显示游戏分数
    public void setScore(int score){
        newImage.clear();    
        Font f = new Font("Comic Sans MS", 34);  //设置字体
        newImage.setFont(f);
        newImage.setColor(Color.YELLOW);
        newImage.drawString("" + score, 30, 30);  //显示分数
        setImage(newImage);
    }
}
