import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Click to try again immediately
 * 
 * 郑斐特
 * 2021.5.19
 */
public class again extends GUI
{
    public static boolean run=false;
    public void act() 
    {
        if ((Greenfoot.mouseClicked(this))){
            blood A=new blood();
            Greenfoot.setWorld(A);
            blood.flag=true;
            run =true;
    }
    }    

}
