import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is going to illustrate the virus
 * 
 * 郑斐特
 * 2021.5.19
 */
public class science_intro extends World
{

    /**
     * Constructor for objects of class science_intro.
     * 
     */
    public science_intro()
    {    
        super(600, 400, 1); 
        addActors();//添加按钮
    }
    private void addActors(){
        vir1 v1=new vir1();
        addObject(v1,70,200);//展示第一个病毒的图片
        vir2 v2=new vir2();
        addObject(v2,215,200);//展示第二个病毒的图片
        vir3 v3=new vir3();
        addObject(v3,360,200);//展示第三个病毒的图片
        vir4 v4=new vir4();
        addObject(v4,505,200);//展示第四个病毒的图片
        back button = new back();
        addObject(button, 520, 350);//展示返回按钮
        choose_virus choose=new choose_virus();
        addObject(choose,300,300);//展示对界面的描述信息
    }
    
}
