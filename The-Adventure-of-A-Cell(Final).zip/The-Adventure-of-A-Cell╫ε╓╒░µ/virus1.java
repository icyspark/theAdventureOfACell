
public class virus1 extends Virus
{
    
}
