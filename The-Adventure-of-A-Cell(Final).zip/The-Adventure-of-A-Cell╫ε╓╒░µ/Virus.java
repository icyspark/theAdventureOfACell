
public abstract class Virus extends Scroller
{
    
}
//This a collection of all kinds of virus that acted as obstacles in the game