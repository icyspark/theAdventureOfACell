import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This give the information concerning the authors of this game
 * 2021.5.19
 */
public class Copyright extends World
{

    /**
     * Constructor for objects of class Copyright.
     * 
     */
    public Copyright()
    {    
        super(600, 400, 1); 
        addActors();
    }
    private void addActors(){
        back button = new back();
        addObject(button, 520, 350);}
}
