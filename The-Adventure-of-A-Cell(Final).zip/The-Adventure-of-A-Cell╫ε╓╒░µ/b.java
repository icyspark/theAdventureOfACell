import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *This a button which can present you the information teaching you how to play
 *the game
 * 
 * 郑斐特
 * 2021.5.20
 */
public class b extends GUI
{
    /**
     * Act - do whatever the b wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if ((Greenfoot.mouseClicked(this))){
            introduction intro=new introduction();
            Greenfoot.setWorld(intro);
    }
    }
    private static b B=new b();
    private b(){};
    public static b getInstance(){
    return B;
}
}
