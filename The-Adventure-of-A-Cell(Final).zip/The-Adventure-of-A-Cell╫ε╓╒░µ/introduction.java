import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is an introduction of this game, telling you how to play.
 * 
 *郑斐特 
 * 2021.5.19
 */
public class introduction extends World
{

    /**
     * Constructor for objects of class introduction.
     * 
     */
    public introduction()
    {    
        super(600, 400, 1); 
        addActors();
    }
    private void addActors(){
        back button = new back();
        addObject(button, 520, 350);}
}
