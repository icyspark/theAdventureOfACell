import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Click to return to the initial interface
 * 
 * 郑斐特
 * 2021.5.19
 */
public class back extends GUI
{
    /**
     * Act - do whatever the back wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       if ((Greenfoot.mouseClicked(this))){
            blood A=new blood();
            Greenfoot.setWorld(A);
    }
    }    
}
