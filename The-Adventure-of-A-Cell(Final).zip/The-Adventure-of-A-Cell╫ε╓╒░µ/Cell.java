import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is the main character of the game.
 * It can avoid the obstacle
 * 郑斐特，卢涵彬
 * The date of the major modification:2021.4.13,2021.4.15,2021.4.16,2021.4.20,
 * 2021.5.5,2021.5.19
 */
public class Cell extends Actor{
    public static final int GRAVITY = 1;  //重力加速度
    public static final int SPEED = 5; //水平速度
    public static final int FLY_SPEED = -9;  //上升速度
    private GreenfootImage cell1 = new GreenfootImage("beginCell.png");
    private GreenfootImage cell2 = new GreenfootImage("coolCell.png");
    private GreenfootImage cell3 = new GreenfootImage("surpriseCell.png");
    private GreenfootImage cell4 = new GreenfootImage("deadCell.png");
    private int speed = 0;    //垂直速度
    private int score = 0;    //分数
    private int counter = 0;    //动画计数器
    
    public void act() {
        
        if(!blood.isPaused&&blood.flag||again.run){
        animation();
        checkClick();  
        flow();
        checkCollision();
        checkScore();
    }
}

    public void animation(){
        counter ++;
        if (counter == 250) {
            setImage(cell1);
        }
        else if (counter == 500) {
            setImage(cell2);
        }
        else if (counter == 750) {
            setImage(cell3);
            counter=0;
        }
    }//变换细胞的表情
    
    
    public void checkCollision(){
        if (isHitted()) {  //若受到冲撞，则游戏结束
            blood blood = (blood) getWorld();
            blood.gameOver();
            setImage(cell4);
        }
    }
    private void checkClick() {
        if (Greenfoot.mousePressed(null)) { 
            speed = FLY_SPEED;
        }
    }
    
    private boolean isHitted() {
        if (isTouching(Virus.class)) {  //撞上病毒
            Greenfoot.playSound("SoundOfHit.mp3");
            return true;
        }
        if (getY() >= getWorld().getHeight() - getImage().getHeight()/2) {  //撞上病毒
            Greenfoot.playSound("hitground.mp3");
            return true;
        }
        return false;
    }
    private void checkScore() {
        if (isTouching(HideLine.class)) {  //若接触得分条则加分
            removeTouching(HideLine.class);
            score++;
            Object obj = getWorld().getObjects(Score.class).get(0);
            ((Score)obj).setScore(score);
        }
    }
    
    private void flow() {
        setLocation(getX(), getY() + speed);  //更新坐标位置
        speed = speed + GRAVITY;  //垂直速度受重力影响 
        setRotation(speed);  //更新旋转角度
    }
}
