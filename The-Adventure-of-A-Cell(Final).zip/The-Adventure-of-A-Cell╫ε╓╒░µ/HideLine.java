
public class HideLine extends Scroller
{
}
