import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a model of a real virus, which is similar to the fourth virus 
 * 郑斐特
 * 2021.5.20
 */
public class real4 extends Actor
{
    /**
     * Act - do whatever the real4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
