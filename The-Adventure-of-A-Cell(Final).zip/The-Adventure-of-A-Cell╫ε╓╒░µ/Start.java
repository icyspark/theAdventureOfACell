import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Click to start the game
 * 
 * 卢涵彬，郑斐特
 * 2021.5.5，2021.5.19
 */
public class Start extends GUI{
    public void act() {
        if ((Greenfoot.mouseClicked(this))||again.run){  //鼠标点击，游戏开始
            blood.isPaused = false;
            getWorld().removeObjects(getWorld().getObjects(GUI.class));
            again.run=true;
            blood.flag=true;
        }
    }
    private static Start start=new Start();
    private Start(){};
    public static Start getInstance(){
    return start;
}
}
