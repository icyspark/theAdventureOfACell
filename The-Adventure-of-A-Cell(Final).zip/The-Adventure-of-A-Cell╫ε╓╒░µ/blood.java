import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * This is the background of the game. It can play the music and add all 
 * objects you see. It is the main controler of the game.
 * 郑斐特，卢涵彬
 * The date of the major modification:2021.4.13,2021.4.15,2021.4.16,2021.4.20,
 * 2021.5.5,2021.5.19
 */

public class blood extends World {
    //private int tick;
    public static final int VIRUS_SPACING = 160;  //上下病毒间的距离
    public static final int VIRUS_MIN_HEIGHT = 50;  //病毒的最小高度
    public static boolean isPaused = true; //游戏的运行状态（新添加）
    private final int VIRUS_INTERVAL = 100;  //两组病毒的间隔距离
    private static int virusTimer1 = 0;  //生成下一组病毒的时间
    private static int virusTimer2 = 0;
    private int scrollX = 0;  //水平滚动坐标
    private  int scrollSpeed = 5;  //滚动速度
    private GreenfootImage backIm1,backIm2;  //保存背景图像
    private GreenfootSound music; //场景音乐
    public static boolean flag=true;
    //构造方法，初始化游戏场景
    public blood() {
        super(600, 400, 1,true); //第4个参数设为true使得角色无法飞出窗口
        isPaused = true;
        virusTimer1 = VIRUS_INTERVAL * 2;
        virusTimer2 = VIRUS_INTERVAL * 2+50;//注意出现时间上与第一组病毒隔开
        backIm1 = backIm2 = new GreenfootImage(getBackground());
        music = new GreenfootSound("Vespera.mp3"); 
        setPaintOrder(GameOver.class, Score.class, Cell.class, Virus.class);
        addActors();
    }

    //游戏循环，更新游戏逻辑
    public void act() {
        if(!isPaused&&flag){
            music.playLoop();  //播放场景音乐
            addVirusPeriodically();//添加病毒
            scrollBackground();  //滚动场景图像
        }//（新添加）
    }    

    //游戏结束
    public void gameOver() {
        music.stop();
        addObject(new GameOver(), getWidth() / 2, getHeight() / 2-60);
        addObject(new again(), getWidth() / 2+70, getHeight() / 2+40);
        addObject(new Exit(), getWidth() / 2-90, getHeight() / 2+40);
        flag=false;
        again.run=false;
    }

    //每隔一段时间自动生成病毒
    private void addVirusPeriodically() {
        virusTimer1--;
        virusTimer2--;
        if (virusTimer1 == 0) {
            addVirus1();
            virusTimer1 = VIRUS_INTERVAL;
        }
        if (virusTimer2 == 0) {
            addVirus2();
            virusTimer2 = VIRUS_INTERVAL;
        }
    }

    //仿照上一段代码，添加第二组病毒
    private void addVirus1() {      
        //添加上方病毒
        virus1 vir1 = new virus1();
        int virusMaxHeight = getHeight() - VIRUS_SPACING - VIRUS_MIN_HEIGHT; //上病毒最大高度
        int height1 = VIRUS_MIN_HEIGHT + Greenfoot.getRandomNumber(virusMaxHeight - VIRUS_MIN_HEIGHT);  //上方病毒高度
        int y1 = height1 - vir1.getImage().getHeight()/2;     //上方病毒的纵坐标
        addObject(vir1 , getWidth() ,  y1);
        //添加下方病毒
        virus2 vir2=new virus2();
        int height2 = getHeight() - height1 - VIRUS_SPACING;  //下方病毒高度
        int y2 = getHeight() - (height2 - vir2.getImage().getHeight()/2);   //下方病毒的纵坐标
        addObject(vir2 , getWidth() , y2);
        //添加隐藏条
        int y5 = height1 + VIRUS_SPACING / 2 - 1;  //隐藏条的纵坐标
        addObject(new HideLine(), getWidth() - vir1.getImage().getWidth()/2, y5);
    }
    
     private void addVirus2() {
        int virusMaxHeight = getHeight() - VIRUS_SPACING - VIRUS_MIN_HEIGHT;
        int height1 = VIRUS_MIN_HEIGHT + Greenfoot.getRandomNumber(virusMaxHeight - VIRUS_MIN_HEIGHT);
        virus3 vir3=new virus3();
        int y3 = height1 - vir3.getImage().getHeight()/2;   //下方病毒的纵坐标
        addObject(vir3 , getWidth() , y3);
        virus4 vir4=new virus4();
        int height4 = getHeight() - height1 - VIRUS_SPACING;  //下方病毒高度
        int y4 = getHeight() - (height4 - vir4.getImage().getHeight()/2);   //下方病毒的纵坐标
        addObject(vir4 , getWidth() , y4);
        int y5 = height1 + VIRUS_SPACING / 2 - 1;  //隐藏条的纵坐标
        addObject(new HideLine(), getWidth() - vir3.getImage().getWidth()/2, y5);
    }
    
    //重新设置场景图像
    public void resetBackImage(){
        GreenfootImage back = getBackground();
        back.drawImage(backIm1, scrollX, 0);
        back.drawImage(backIm2, scrollX + getWidth(), 0);
    }

    //滚动场景图像
    public void scrollBackground(){
        int speed=scrollSpeed;
        scrollX = (scrollX - scrollSpeed) % getWidth(); //循环滚动
        resetBackImage();
    }

    //在场景中添加游戏角色
    private void addActors(){
        Title title = Title.getInstance();
        addObject(title, 301, 72);//添加标题
        Start start = Start.getInstance();
        addObject(start, 290, 300);//添加开始按钮
        Cell cell = new Cell();
        addObject(cell, 291, 207);//添加游戏主体：细胞
        Score score = new Score();
        addObject(score, 55, 387);//添加计分器
        a copyright =a.getInstance();
        addObject(copyright,500,320);//添加引导按钮，点击可访问作者信息
        b introduction =b.getInstance();
        addObject(introduction,480,350);//添加引导按钮，点击可访问游戏信息
        c introduction2 =c.getInstance();
        addObject(introduction2,480,380);//点击引导按钮，点击可访问病毒相关资料（科普）
        mouse M=new mouse();
        addObject(M,290,350);//鼠标图案，引导用户开始游戏
    }
    
}

